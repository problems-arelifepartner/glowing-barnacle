module.exports = {
  help: () =>
    `🤖 *Jarvis - WhatsApp AI Assistant*\n\nCommands:\n` +
    `• .ai <msg> — Chat with Jarvis\n` +
    `• .reset — Reset your chat\n` +
    `• .help — Show this menu\n\n` +
    `You can also send voice messages.`,
};
